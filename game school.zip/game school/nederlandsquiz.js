var antwoord;
alert("deze quiz gaat over nederland. denk jij dat je kan winnen?")
antwoord = prompt("hoeveel provincies heeft nederland?","kies uit: 11 of 12");

if (antwoord == "12"){
	console.log("Goed antwoord op aantal provincies")
		antwoord = prompt("wat is de hoofdstad van overijssel?", "kies uit: drenthe of zwolle");	
		if (antwoord == "zwolle"){
			console.log("goed antwoord op hoofdstad")
			 antwoord = prompt("in welk jaar werdt de eerste nederlandse grondwet gepubliceerd?","kies uit: 1815 of 1983");
				if(antwoord == "1815"){
					console.log("goed antwoord op publicatiejaar")
					antwoord = prompt("in welke provincie ligt tiel?","kies uit:utrecht of gelderland");
					if(antwoord == "gelderland"){
						console.log("goed antwoord op provincie")
						alert("gefeliciteerd! je hebt de quiz gewonnen")
					}
					else{
						console.log("fout antwoord op provincie")
						alert("helaas. je hebt de quiz verloren")
					}
				}
				else{console.log("fout antwoord op publicatiejaar")
					antwoord = prompt("wat is in nederlands het meest gedronken biertype?","kies uit: heineken of pils")
					if(antwoord == "pils"){
						console.log("goed antwoord op meest gedronken biertype")
						alert("gefeliciteerd! je hebt de quiz gewonnen")
					}
					else{
						console.log("fout antwoord op meest gedronken biertype")
						alert("helaas. je hebt de quiz verloren")
					}
				}	
		}		
		else{
			console.log("fout antwoord op hoofdstad")
			antwoord = prompt("in welk jaar is koningin beatrix geboren?","kies uit: 1937 of 1938")
			if(antwoord == "1838"){
				console.log("geboortjaar jaar beatrix goed")
				alert("gefeliciteerd! je hebt de quiz gewonnen")
			}
			else{
				console.log("geboorte jaar beatrix fout")
				alert("helaas. je hebt de quiz verloren")
			}
		}
				
}		
else{
	console.log("fout antwoord op aantal provincies")
	antwoord = prompt("welk pretpark ligt in limburg?","kies uit: toverland of walibi")
	if(antwoord == "toverland"){
		console.log("goed antwoord pretpark")
		antwoord = prompt("zijn er meer of minder dan 260 mcdonalds filialen in nederland?","kies uit: meer, minder of 260")
		if(antwoord == "260"){
			console.log("goed antwoord filialen")
			alert("gefeliciteerd! je hebt de quiz gewonnen")
		}
		else{
			console.log("fout antwoord filialen")
			alert("helaas.je hebt de quiz verloren")
		}
	}
	else{
		console.log("fout antwoord pretpark")
		antwoord = prompt("wat is het meest gebruikte vervoersmiddel in nederland?","kies uit: auto of fiets")
		if(antwoord == "auto"){
			console.log("goed antwoord vervoersmiddel")
			antwoord = prompt("wat was de eerste nederlandse televisieomroep?","kies uit: nts of nto")
			if(antwoord == "nts"){
				console.log("goed antwoord eerste televisieomroep")
				alert("gefeliciteerd! ondanks je de makkeljke vragen fout heb  win je toch voor de moeite")
			}
			else{
				console.log("fout antwoord televisieomroep")
				alert("helaas.je hebt de quiz")
			}
		}
		else{
			console.log("fout antwoord vervoersmiddel")
			alert("helaas. je hebt de quiz verloren")
		}
	}	

}	

